!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
!!!! WARNING WARNING WARNING WARNING WARNING WARNING WARNING WARNING WARNING !!!!
!!!! WARNUNG WARNUNG WARNUNG WARNUNG WARNUNG WARNUNG WARNUNG WARNUNG WARNUNG !!!!
!!!! Uyari Uyari Uyari Uyari Uyari Uyari Uyari Uyari Uyari Uyari Uyari Uyari !!!!
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

ENGLISH:
========

Step 2 - INITRD (Rescue Mode)

1.) Delete ALL files&folders from step 1 CFE on your usbstick.
2.) Copy ALL files&folders from the folder "Step 2 - INITRD (Rescue Mode)" to a usbstick.
3.) Power OFF your STB on main power switch.
4.) Plug the usbstick to your STB and switch power ON.
    Your STB will automatically start flashing the INITRD (Rescue Mode).
5.) Your STB will automatically boot into "Rescue Mode" after flashing of INITRD (Rescue Mode).
6.) Unplug the usbstick.
7.) Either flash the backup of your image as zip-file using "Rescue Mode"
    or flash the backup regularly using a usbstick.
8.) Continue reading "3 - EN - Informations - Rescue Mode.pdf".

===========================================================================================================
===========================================================================================================

DEUTSCH:
========

Schritt 2 - INITRD (Rescue Mode)

1.) Löschen Sie ALLE Dateien&Ordner von Schritt 1 CFE von Ihrem USB-Stick.
2.) Kopieren Sie ALLE Dateien&Ordner aus dem Ordner "Step 2 - INITRD (Rescue Mode)" auf einen USB-Stick.
3.) Schalten Sie die STB am Netzschalter AUS.
4.) Stecken Sie den USB-Stick an die STB und schalten Sie die STB am Netzschalter EIN.
    Ihre STB wird automatisch mit dem Flashen von INITRD (Rescue Mode) starten.
5.) Ihre STB wird nach dem flashen von INITRD (Rescue Mode) automatisch in den "Rescue Mode" starten.
6.) Entfernen Sie den USB-Stick.
7.) Entweder flashen Sie Ihre Sicherung des Images als zip-Datei mit Hilfe des "Rescue Mode"
    oder Sie flashen die Sicherung wie immer mit Hilfe eines USB-Sticks.
8.) Fahren Sie fort mit "3 - DE - Informationen - Rettungs Modus.pdf".

===========================================================================================================
===========================================================================================================

TÜRK:
=====

Adim 2 - INITRD (Kurtarma Modu)

1.) Tüm dosyalari ve klasörleri  USB nizden silin.
2.) Adim 2-INITRD dosyasinin icindeki  Tüm dosyalari ve klasörleri (Kurtarma Modu) bir
    USB-Sticke kopyalayin.
3.) Cihazinizi (STB) ana güç dügmesinden kapatin.
4.) Cihaziniza (STB) USB sticki yerlestirin ve güç dügmesinden açin.
    Cihaziniz (STB) (kurtarma modunda) INITRD ile otomatik flas ile baslayacaktir.
5.) Cihaziniz (STB) otomatik olarak INITRD (Kurtarma Modu) girecektir, flas den sonra
   "Kurtarma Modu" baslayacaktir.
6.) USB sticki çikarin.
7.) Ya "Kurtarma Modu" seçenegini kullanarak bir zip dosyasinda olan Image´nizi yükliyebilirsiniz.
    veya bir USB stick yardimiyla her zaman oldugu gibi yeni veya yedeklediginiz yaziliminizi yükliyebilirsiniz.
8.) "3 - TR - Bilgi - Kurtarma Modu.pdf" ile devam edin.


IMPEX-SAT GmbH&Co.KG - 2015

!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
!!!! WARNING WARNING WARNING WARNING WARNING WARNING WARNING WARNING WARNING !!!!
!!!! WARNUNG WARNUNG WARNUNG WARNUNG WARNUNG WARNUNG WARNUNG WARNUNG WARNUNG !!!!
!!!! Uyari Uyari Uyari Uyari Uyari Uyari Uyari Uyari Uyari Uyari Uyari Uyari !!!!
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

ENGLISH:
========

Step 1 - CFE (Bootloader)

Flashing this CFE will reorganize and resize the flash devices of your settopbox (STB).
Your STB will no longer boot with your previously installed software!

1.) Create a fullbackup of your image.
2.) Create a backup of your settings (optional).
3.) Copy fullback of image and optional backup of settings to a save location.
4.) Copy ALL files&folders from the folder "Step 1 - CFE (Bootloader)" to a usbstick.
5.) Power OFF your STB on main power switch.
6.) Plug the usbstick to your STB and switch power ON.
    Your STB will automatically start flashing the CFE.
7.) Wait untill the blue GigaBlue Logo "GB" on white/grey background is shown on your TV.
8.) Power OFF your STB on main power switch.
9.) Unplug the usbstick.
10.) Continue with "2 - ReadMe Step 2 - Liesmich Schritt 2 - Adim 2 - INITRD (Rescue Mode).txt".

===========================================================================================================
===========================================================================================================

DEUTSCH:
========

Schritt 1 - CFE (Bootloader)

Das Flashen dieses CFE's wird die Einteilung des Flashspeichers Ihrer Settopbox (STB) reorganisieren und Gr��en ver�ndern.
Ihre STB wird nicht mehr mit der zuvor installierten Software starten!

1.) Erstellen Sie eine vollst�ndige Sicherung Ihres Images (Fullbackup).
2.) Erstellen Sie eine Sicherung Ihrer Einstellungen (optional).
3.) Kopieren Sie die vollst�ndige Sicherung Ihres Images und die optionale Sicherung Ihrer Einstellungen an einen sicheren Ort.
4.) Kopieren Sie ALLE Dateien&Ordner aus dem Ordner "Step 1 - CFE (Bootloader)" auf einen USB-Stick.
5.) Schalten Sie die STB am Netzschalter AUS.
6.) Stecken Sie den USB-Stick an die STB und schalten Sie die STB am Netzschalter EIN.
    Ihre STB wird automatisch mit dem Flashen des CFE's starten.
7.) Warten Sie bis das blaue GigaBlue Logo "GB" auf wei�/grauem Hintergrund auf dem TV zu sehen ist.
8.) Schalten Sie die STB am Netzschalter AUS.
9.) Entfernen Sie den USB-Stick.
10.) Fahren Sie fort mit "2 - ReadMe Step 2 - Liesmich Schritt 2 - Adim 2 - INITRD (Rescue Mode).txt".

===========================================================================================================
===========================================================================================================

T�RK:
=====

Adim 1 - CFE (Bootloader)

Bu CFE yi Flash yaptiginiz takidirde Boxunuzun (STB) flash bellek b�l�m� yeniden d�zenlenicek ve boyutlarini degistirecektir.
Sizin cihaziniz (STB) artik yazilimdan �nce y�kl� olan Image ile calismayacaktir!

1.) Tam Backup yedegini olusturun (Fullbackup)
2.) Ayarlarinizi (istege bagli) bir yedegini alin.
3.) G�r�nt�lerin tam yedekleme ve g�venli bir yere ayarlarinizi opsiyonel yedekleme kopyalayin.
4.) T�m dosyalari ve klas�rleri kopyalayin. Bir USB sticke. Step1 CFE (Bootloader)
5.) Cihazinizi (STB) arkadaki ana g�� d�gmesinden kapatin.
6.) Cihazinizi (STB)  USB stick yerlestirin ve g�� d�gmesini (STB) a�in.
    CFE g�ncelleme otomatik olarak baslayacaktir.
7.) TV'de beyaz / gri arka plan �zerine mavi GigaBlue logosu "GB� g�r�n�nceye kadar bekleyin.
8.) yeni GB Logosunu g�r�nce cihazinizi (STB) ana g�� d�gmesinden kapatin.
9.) USB stick �ikarin.
10.) BeniOku Adim "2 - ReadMe Step 2 - Liesmich Schritt 2 - Adim 2 - INITRD (Rescue Mode).txt".

IMPEX-SAT GmbH&Co.KG - 2015
